export class Usuario{
    correo: string;
    password: string;
    constructor() {
        this.correo = 'prueba@gmail.com';
        this.password = 'prueba';
    }
}