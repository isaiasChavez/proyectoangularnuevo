export class ProfesorYMateria{
    idProfesor: number;
    idMateria: number;
    grupo: number;
    anyo:number;
    idPeriodo:number;
    constructor() {
        this.idProfesor=0;
        this.idMateria=0;
        this.grupo=0;
        this.anyo=0;
        this.idPeriodo=0;
    }
}