export class Institutos{
    nombre: string;
    codigo: string;
    constructor() {
        this.codigo='';
        this.nombre='';
    }
}