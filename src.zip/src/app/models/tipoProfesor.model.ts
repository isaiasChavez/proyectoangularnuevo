export class TipoProfesor{
    nombreTipo: string;
    constructor() {
        this.nombreTipo='';
    }
}