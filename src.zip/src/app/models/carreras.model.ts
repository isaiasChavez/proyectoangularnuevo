export class Carreras{
    codigoCarrera: string;
    nombreCarrera: string;
    idInstituto: number;
    constructor() {
        this.codigoCarrera='';
        this.nombreCarrera='';
        this.idInstituto=0;
    }
}