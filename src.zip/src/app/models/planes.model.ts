export class Planes{
    idCarrera: number;
    nombrePlan : string;
    constructor() {
        this.idCarrera=0;
        this.nombrePlan='';
    }
}