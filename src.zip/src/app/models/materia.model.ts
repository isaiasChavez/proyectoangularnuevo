export class Materia{
    idPlan: number;
    semestre: number;
    nombreMateria: string;
    constructor() {
        this.idPlan=0;
        this.semestre=0;
        this.nombreMateria='';
    }
}